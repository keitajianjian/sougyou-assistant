# 創業計画書アシスタント — デプロイ手順

## ファイル構成
```
sougyou-app/
├── api/
│   └── chat.js        ← APIキーを保護するサーバー関数
├── public/
│   └── index.html     ← フロントエンド（お客さんが開く画面）
├── vercel.json        ← Vercel設定
└── README.md
```

## デプロイ手順（所要時間：約10分）

### 1. GitHubにアップロード
1. https://github.com にアクセスしてアカウント作成（無料）
2. 「New repository」でリポジトリ作成（名前例：sougyou-assistant）
3. このフォルダの中身をアップロード

### 2. Vercelにデプロイ
1. https://vercel.com にアクセスしてGitHubアカウントで登録（無料）
2. 「New Project」→ 先ほどのGitHubリポジトリを選択
3. 「Deploy」をクリック → 1〜2分で完成

### 3. APIキーを設定（重要）
1. Vercelのダッシュボードで作成したプロジェクトを開く
2. 「Settings」→「Environment Variables」
3. 以下を追加：
   - Name: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-...（あなたのAPIキー）`
4. 「Save」→「Redeploy」

### 4. URLをお客さんに共有
デプロイ完了後、`https://（プロジェクト名）.vercel.app` というURLができます。
このURLをnote・LINE・メール等でお客さんに渡すだけで使えます。

## コスト目安
- Vercel：無料プラン（月100GB帯域まで無料）
- Anthropic API：1回の相談あたり約3〜10円程度
  （1ヶ月100人が使っても500〜1,000円程度）

## カスタマイズ
- `public/index.html` の最上部のヘッダー名や色を変えることでブランドを変更できます
- APIモデルは `api/chat.js` の `model` を変更で切り替えできます
